using UnityEngine;
[RequireComponent(typeof(Collider2D))]
public class ExitZone : MonoBehaviour
{
    private void Awake() { GetComponent<Collider2D>().isTrigger = true; }
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.GetComponent<PlayerController>() != null) GameManager.Instance.TryFinishLevel();
    }
}
